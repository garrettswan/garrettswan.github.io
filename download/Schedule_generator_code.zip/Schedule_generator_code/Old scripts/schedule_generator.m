function schedule_generator

% ADD MORNING AFTERNOON EVENING WEIGHTS
% Put people here

person{1,1} = 'sammy_time_sheet';
person{1,2} = 4; % number of hours

person{2,1} = 'timmy_time_sheet';
person{2,2} = 4; % number of hours
% 
% person{3,1} = 'Mike';
% person{3,2} = 4; % number of hours
% 
% person{4,1} = 'Sage';
% person{4,2} = 4; % number of hours
% 
% person{5,1} = 'Alex';
% person{5,2} = 4; % number of hours
% 
% person{6,1} = 'Brad';
% person{6,2} = 0; % number of hours
%  
% person{7,1} = 'Andrew';
% person{7,2} = 4; % number of hours
% 
% person{8,1} = 'Stephanie';
% person{8,2} = 4; % number of hours

% person{6,1} = 'Natalie';
% person{6,2} = 5; % number of hours
% 
% person{14,1} = 'Emily';
% person{14,2} = 4; % number of hours


count = 0;
for i = 1:size(person,1)
    if isempty(person{i,1})==0
        
        count = count + 1;
        
        eval(sprintf('%s = csvread(''%s.csv'',0,1,[0,1,95,5]);',person{i,1},person{i,1}));
        eval(sprintf('%s = check_dim(%s);',person{i,1},person{i,1}));
        eval(sprintf('people_time_sheet(%g,:,:) = mod(%s+1,2);',count,person{i,1}));
        
        num_people(count) = i;
    end
end

% Some parameters

total_units = min(sum(cellfun(@sum,person))); % Total number of assigned hours
unit_length = 4; % hour time slots

num_days = 5; % Monday through friday

generate_schedule = 1;
test_schedule = 1;

lab_meeting = 0; % finds a common time between all people
lab_meeting_found = 259:262; % if there is already a lab meeting time, input here. Otherwise, leave at 0
lab_meeting_duration = 4; % in units of 15 minutes

%lab_meeting = 1; % finds a common time between all people
%lab_meeting_found = 0; % if there is already a lab meeting time, input here. Otherwise, leave at 0
%lab_meeting_duration = 4; % in units of 15 minutes

earliest_slot = 40; % 36 = 9:00am;
latest_slot= 72; % 68 = 5:00pm

% Don't touch these things:
time_sheet = zeros(96,num_days)+1;

time_sheet(1:earliest_slot,:) = 0;
time_sheet(latest_slot:96,:) = 0;
total_people = size(people_time_sheet,1);

unit_length = unit_length-1; % have to minus 1 because this includes the current time slot
lab_meeting_duration = lab_meeting_duration -1;% have to minus 1 because this includes the current time slot

load time
final_time_sheet = num2cell([time_sheet time]);

%num_people = 1:total_people;
possible_person = num_people(cell2mat(cellfun(@(x) x>0, person(:,2) , 'UniformOutput', false)));

fid = fopen('time_index.csv');
out = textscan(fid,'%s%f','delimiter',',');
time_index = out{1};
fclose(fid);

if lab_meeting
    
    collapsed_schedule = sum(people_time_sheet,1);
    
    possible_people_times = find(collapsed_schedule == size(people_time_sheet,1));
    possible_schedule_times = find(time_sheet == 1);
    
    possible_meeting_times = possible_people_times(ismember(possible_people_times,possible_schedule_times));
    
    possible_meeting_time = possible_meeting_times(ceil(rand*length(possible_meeting_times)));
    
    lab_meeting_count = 0;
    while (sum(ismember(possible_meeting_times,possible_meeting_time:possible_meeting_time+lab_meeting_duration))==4) ~= 1
        lab_meeting_count = lab_meeting_count + 1;
        if lab_meeting_count > 1000
            'no good lab time'
            return
        end
        possible_meeting_time = possible_meeting_times(ceil(rand*length(possible_meeting_times)));
    end
    
    if lab_meeting_count < 1000
        final_time_sheet{possible_meeting_time} = 'LAB';
        final_time_sheet{possible_meeting_time+1} = 'LAB';
        final_time_sheet{possible_meeting_time+2} = 'LAB';
        final_time_sheet{possible_meeting_time+3} = 'LAB';
        
        time_sheet(possible_meeting_time) = 0;
        time_sheet(possible_meeting_time+1) = 0;
        time_sheet(possible_meeting_time+2) = 0;
        time_sheet(possible_meeting_time+3) = 0;
        
    end
    
elseif lab_meeting_found ~= 0
    
    final_time_sheet{lab_meeting_found(1)} = 'LAB';
    final_time_sheet{lab_meeting_found(2)} = 'LAB';
    final_time_sheet{lab_meeting_found(3)} = 'LAB';
    final_time_sheet{lab_meeting_found(4)} = 'LAB';
    
    time_sheet(lab_meeting_found(1)) = 0;
    time_sheet(lab_meeting_found(2)) = 0;
    time_sheet(lab_meeting_found(3)) = 0;
    time_sheet(lab_meeting_found(4)) = 0;
    
end

if generate_schedule
    for i = 1:total_units
        
        searching = 0;
        
        count_1 =0;
        while searching == 0
            
            % randomly select a person
            which_person(i) = possible_person(ceil(rand*length(possible_person)));
            
            % randomly select a day
            which_day = ceil(rand*num_days);
            
            % find open times for specific person for specific day and see
            % what times are also free on the master schedule
            open_times = find(time_sheet(1:96,which_day) == 1);
            try
            open_times_person = find(people_time_sheet(which_person(i),:,which_day)==1)';
            catch
                keyboard
            end
            % these are the possible times
            possible_times = open_times(ismember(open_times,open_times_person));
            
            if isempty(possible_times)==0
                % this is the randomly selected timef
                possible_time = possible_times(ceil(rand*length(possible_times)));
                
                % here are some constraints:
                % the first states that the time slot must be either starting on
                %      the hour or between hours
                % the second states that the next 4 slots must be free after
                %      the selected time, which means we want hour time slots
                count_2 = 0;
                while sum([mod(possible_time,2) ~= 0 sum(ismember(possible_times,possible_time:possible_time+unit_length))==4]) ~= 2
                    possible_time = possible_times(ceil(rand*length(possible_times)));
                    count_2 = count_2 + 1;
                    if count_2 > 1000
                        no_fit = 1;
                        break
                    end
                end
                
                % as long as a time slot has been found, we can now add it to
                % the master list master list
                if count_2 <= 1000
                    searching = 1;
                    
                    final_time_sheet{possible_time,which_day} = person{which_person(i),1};
                    final_time_sheet{possible_time+1,which_day} = person{which_person(i),1};
                    final_time_sheet{possible_time+2,which_day} = person{which_person(i),1};
                    final_time_sheet{possible_time+3,which_day} = person{which_person(i),1};
                    
                    time_sheet(possible_time,which_day) = which_person(i)+1;
                    time_sheet(possible_time+1,which_day) = which_person(i)+1;
                    time_sheet(possible_time+2,which_day) = which_person(i)+1;
                    time_sheet(possible_time+3,which_day) = which_person(i)+1;
                    
                    % [which_person_most how_many] = mode(which_person(ismember(which_person,possible_person)));
                    
                    % if that person has enough hours, take him off the list
                    if i ~= total_units
                        for a_person = 1:size(people_time_sheet,1)
                            if person{a_person,2} == length(find(which_person == a_person));
                                
                                possible_person(find(possible_person == a_person)) = [];
                                
                            end
                        end
                        
                    end
                    
                    
                end
                
                count_1 = count_1+1;
                if count_1 > 1000
                    'no good research hours'
                    return
                end
                
            end
        end
    end
else
    load schedule
end

% If you want to make sure the current schedule doesn't conflict with the
% time slots of the people
if test_schedule
    result = test_schedule_script(time_sheet,people_time_sheet);
    
    if min(result) == 0
        'good schedule'
    else
        'bad schedule'
    end
    
end

final_time_sheet
keyboard

end

function result = test_schedule_script(time_sheet,people_time_sheet)

result = 0;

count = 0;

for person = 1:size(people_time_sheet,1)
    
    person_index = person+1;
    
    when_scheduled = find(time_sheet == person_index);
    person_schedule = find(people_time_sheet(person,:,:) == 0);
    
    if sum(ismember(when_scheduled,person_schedule)) > 1
        count = count + 1;
        result(count) = person;
        
    end
end

end

function dist = check_dim(dist)

if size(dist,1)*size(dist,2) ~= 480
    if max([size(dist,1) size(dist,2)]) > 96
        return
    end
end


end




