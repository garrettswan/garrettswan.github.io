function [sample] = prob_with_weights(index,weights)

% weights should sum to 1

if nargin == 1
    weights = zeros(length(index),1)+(1/length(index));
end

if length(index)~=length(weights)
   beep
    'LENGTHS ARE WRONG'
    keyboard 
end

weights = weights/(sum(weights));


count = 0;
for i = 1:length(index)
    for j = 1:ceil(weights(i)*100)
        count = count + 1;
        vec(count) = index(i);
        
    end
end

samples = Shuffle(vec);
sample = samples(1);

end