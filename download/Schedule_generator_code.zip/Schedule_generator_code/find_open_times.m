function find_open_times

source_filescsv = dir(fullfile(pwd, '*time_sheet.csv'));
source_filesmat = dir(fullfile(pwd, '*etc.mat'));
count = 0;

for i = 1:length(source_filescsv)
    
    count = count + 1;
    load(source_filesmat(i).name)
    
    person{count,1} = source_filescsv(i).name(1:end-15);
    person{count,2} = sona_hour;
    
    eval(sprintf('%s = csvread(''%s'',0,1,[0,1,95,5]);',person{count,1},source_filescsv(i).name));
    eval(sprintf('%s = check_dim(%s);',person{count,1},person{count,1}));
    eval(sprintf('people_time_sheet(%g,:,:) = mod(%s+1,2);',count,person{count,1}));
    
end

num_days = 5; % Monday through friday

earliest_slot = 34; % 36 = 9:00am; %34
latest_slot= 72; % 68 = 5:00pm % 72

% Don't touch these things:
time_sheet = zeros(96,num_days)+1;

time_sheet(1:earliest_slot,:) = 0;
time_sheet(latest_slot:96,:) = 0;

fid = fopen('time_index.csv');
out = textscan(fid,'%s%f','delimiter',',');
time_index = out{1};
fclose(fid);

collapsed_schedule = sum(people_time_sheet,1);

possible_people_times = find(collapsed_schedule == size(people_time_sheet,1));
possible_schedule_times = find(time_sheet == 1);
possible_meeting_times = possible_people_times(ismember(possible_people_times,possible_schedule_times));

disp('***********************');
disp('Possible meeting times');
disp(time_index(possible_meeting_times));
disp('***********************');
end