function [new_da_time] = time_conversion(da_time,when)


if when == 1
    
    s_time = num2str(da_time);
    minutes = str2num(s_time((end-1):end));
    incr = floor(minutes/15);
    
    new_s_da_time = num2str(((mod(incr,4)+1)*15)-15);
    if new_s_da_time == '0'
        new_s_da_time = '00';
    end
    
    
    if length(s_time)==4
        new_da_time = str2num([s_time(1:2) new_s_da_time]);
    else
        new_da_time = str2num([s_time(1) new_s_da_time]);
    end
    
elseif when == 2
    
    
    s_time = num2str(da_time);
    
    if s_time((end-1):end)=='00'
        if length(s_time)==4
            new_da_time = str2num([num2str(str2num(s_time(1:2))-1) '45']);
        else
            new_da_time = str2num([num2str(str2num(s_time(1))-1) '45']);
        end
    else
        minutes = str2num(s_time((end-1):end));
        incr = floor(minutes/15);
        
        new_s_da_time = num2str(((mod(incr,4)+1)*15)-15);
        
        if new_s_da_time == '0'
            new_s_da_time = '00';
        end
        
        if length(s_time)==4
            new_da_time = str2num([s_time(1:2) new_s_da_time]);
        else
            new_da_time = str2num([s_time(1) new_s_da_time]);
        end
    end
    
    
    
end


end

