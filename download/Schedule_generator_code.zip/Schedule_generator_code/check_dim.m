function dist = check_dim(dist)

if size(dist,1)*size(dist,2) ~= 480
    if max([size(dist,1) size(dist,2)]) > 96
        return
    end
end


end
