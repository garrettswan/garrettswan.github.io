function schedule_generator

source_filescsv = dir(fullfile(pwd, '*time_sheet.csv'));
source_filesmat = dir(fullfile(pwd, '*etc.mat'));
count = 0;

for i = 1:length(source_filescsv)
    
    count = count + 1;
    
    load(source_filesmat(i).name)
    
    person{count,1} = source_filescsv(i).name(1:end-15);
    person{count,2} = sona_hour;
    
    eval(sprintf('%s = csvread(''%s'',0,1,[0,1,95,5]);',person{count,1},source_filescsv(i).name));
    eval(sprintf('%s = check_dim(%s);',person{count,1},person{count,1}));
    eval(sprintf('people_time_sheet(%g,:,:) = mod(%s+1,2);',count,person{count,1}));
    
    sona(count) = sona_hour;
    slot_length(count) = sona_length;
    weights{count} = w;
    num_people(count) = i;
    
end

% Some parameters
total_units = sum(sona); % Total number of assigned hours

num_days = 5; % Monday through friday

generate_schedule = 1;
test_schedule = 1;

earliest_slot = 34; % 36 = 9:00am; %34
latest_slot= 76; % 68 = 5:00pm % 72

% Don't touch these things:
time_sheet = zeros(96,num_days)+1;

time_sheet(1:earliest_slot,:) = 0;
time_sheet(latest_slot:96,:) = 0;
total_people = size(people_time_sheet,1);

load time
final_time_sheet = num2cell([time_sheet time]);

[time_sheet final_time_sheet] = check_for_fixed_times(time_sheet,final_time_sheet);

%num_people = 1:total_people;
possible_person = num_people(cell2mat(cellfun(@(x) x>0, person(:,2) , 'UniformOutput', false)));

if generate_schedule
    done_count = 0;
    
    curr_unit = 1;
    count_1 =0;
    % has to be greater because curr_unit is a count and when curr_unit is
    % equal to total units, the last unit still needs to be assigned
    while curr_unit <= total_units
                
        searching = 0;
        while searching == 0
            
            %             % old way
            %             % randomly select a person
            %             which_person(i) = possible_person(ceil(rand*length(possible_person)));
            %
            %             % randomly select a day
            %             which_day = ceil(rand*num_days);
            
            % new way %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            for pp = possible_person
                person_w(pp) = sum(cellfun(@sum,weights{pp}));
            end
            
            which_person(curr_unit) = prob_with_weights(possible_person,person_w(possible_person));
            %person{which_person(i)}
            which_day = prob_with_weights(1:num_days,cellfun(@sum,weights{which_person(curr_unit)}));
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % find open times for specific person for specific day and see
            % what times are also free on the master schedule
            open_times = find(time_sheet(1:96,which_day) == 1);
            try
                open_times_person = find(people_time_sheet(which_person(curr_unit),:,which_day)==1)';
            catch
                keyboard
            end
            % these are the possible times
            possible_times = open_times(ismember(open_times,open_times_person));
            
            if isempty(possible_times)==0
                
                %                 % old way
                %                 % this is the randomly selected timef
                %                 possible_time = possible_times(ceil(rand*length(possible_times)));
                %
                %                 % here are some constraints:
                %                 % the first states that the time slot must be either starting on
                %                 %      the hour or between hours
                %                 % the second states that the next 4 slots must be free after
                %                 %      the selected time, which means we want hour time slots
                %                 count_2 = 0;
                %                 while sum([mod(possible_time,2) ~= 0 sum(ismember(possible_times,possible_time:possible_time+unit_length))==4]) ~= 2
                %                     possible_time = possible_times(ceil(rand*length(possible_times)));
                %                     count_2 = count_2 + 1;
                %                     if count_2 > 1000
                %                         no_fit = 1;
                %                         break
                %                     end
                %                 end
                
                % new way %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % this is the randomly selected timef
                zone_incr = length(earliest_slot:latest_slot)/3;
                possible_time_zone = prob_with_weights(1:3,weights{which_person(curr_unit)}{which_day});
                
                switch possible_time_zone
                    case 1 % only the first third of possible time slots
                        zone_time = possible_times(possible_times>earliest_slot & (possible_times<(earliest_slot+zone_incr)));
                    case 2 % only the middle third of possible time slots
                        zone_time = possible_times((possible_times>(earliest_slot+zone_incr)) & (possible_times<(earliest_slot+(zone_incr*2))));
                    case 3 % only the last third of possible time slots
                        zone_time = possible_times(possible_times>(earliest_slot+(zone_incr*2)) & possible_times<latest_slot);
                end
                
                if isempty(zone_time)
                    possible_time = possible_times(ceil(rand*length(possible_times)));
                else
                    possible_time = zone_time(ceil(rand*length(zone_time)));
                end
                
                
                % where the magic happens
                % here are some constraints:
                % the first states that the time slot must be either starting on
                %      the hour or between hours
                % the second states that the next 4 slots must be free after
                %      the selected time, which means we want hour time slots
                count_2 = 0;
                while sum([mod(possible_time,2) ~= 0 sum(ismember(possible_times,possible_time:possible_time+slot_length(which_person(curr_unit))-1))==(slot_length(which_person(curr_unit)))]) ~= 2
                    
                    possible_time_zone = prob_with_weights(1:3,weights{which_person(curr_unit)}{which_day});
                    
                    switch possible_time_zone
                        case 1 % only the first third of possible time slots
                            zone_time = possible_times(possible_times>earliest_slot & (possible_times<(earliest_slot+zone_incr)));
                        case 2 % only the middle third of possible time slots
                            zone_time = possible_times((possible_times>(earliest_slot+zone_incr)) & (possible_times<(earliest_slot+(zone_incr*2))));
                        case 3 % only the last third of possible time slots
                            zone_time = possible_times(possible_times>(earliest_slot+(zone_incr*2)) & possible_times<latest_slot);
                    end
                    
                    if isempty(zone_time)
                        possible_time = possible_times(ceil(rand*length(possible_times)));
                    else
                        possible_time = zone_time(ceil(rand*length(zone_time)));
                    end
                    
                    count_2 = count_2 + 1;
                    if count_2 > 1000
                        no_fit = 1;
                        break
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % as long as a time slot has been found, we can now add it to
                % the master list master list
                if count_2 <= 1000
                    searching = 1;
                    
                    for pt = possible_time:(possible_time+slot_length(which_person(curr_unit))-1)
                        final_time_sheet{pt,which_day} = person{which_person(curr_unit),1};
                        time_sheet(pt,which_day) = which_person(curr_unit)+1;
                    end

                    add_time(curr_unit) = possible_time;
                    add_day(curr_unit) = which_day;
                    
                    % if that person has enough hours, take him off the list
                    if curr_unit ~= total_units
                        for a_person = 1:size(people_time_sheet,1)
                            if person{a_person,2} == length(find(which_person == a_person));
                                
                                possible_person(find(possible_person == a_person)) = [];
                                
                                done_count = done_count + 1;
                                done_person(done_count) = a_person;
                                
                            end
                        end
                    end
                    
                    % if it couldn't find a spot, randomly delete
                    % someone's existing spot
                elseif length(which_person) > 1
                    
                    curr_unit = curr_unit - 1;
                    
                    % have to minus 1 because we cannot delete the latest
                    % person because they haven't been added! 
                    
                    try
                    fuu = randi(length(which_person)-1);
                    catch
                        keyboard
                    end
                    
                    for pt = add_time(fuu):(add_time(fuu)+slot_length(which_person(fuu))-1);
                        final_time_sheet{pt,add_day(fuu)} = 1;
                        time_sheet(pt,add_day(fuu)) = 1;
                    end
                 %   final_time_sheet{add_time(fuu)+1,add_day(fuu)} = 1;
                 %   final_time_sheet{add_time(fuu)+2,add_day(fuu)} = 1;
                 %   final_time_sheet{add_time(fuu)+3,add_day(fuu)} = 1;
                    
                 %   time_sheet(add_time(fuu),add_day(fuu)) = 1;
                 %   time_sheet(add_time(fuu)+1,add_day(fuu)) = 1;
                 %  time_sheet(add_time(fuu)+2,add_day(fuu)) = 1;
                 %   time_sheet(add_time(fuu)+3,add_day(fuu)) = 1;
                    
                    % this means that the chosen person needs to be added
                    % back to the possible person list
                    if max(which_person(fuu)==possible_person)==0
                        possible_person(end+1) = which_person(fuu);
                    end
                    
                    add_time(fuu) = [];
                    add_day(fuu) = [];
                    which_person(fuu) = [];
                end
                
                count_1 = count_1+1;
                if count_1 > 1000
                    'no good research hours'
                    return
                end
                
            end
        end
        
        curr_unit = curr_unit + 1;
        
    end
else
    load schedule
end

% If you want to make sure the current schedule doesn't conflict with the
% time slots of the people
if test_schedule
    result = test_schedule_script(time_sheet,people_time_sheet);
    
    if min(result) == 0
        disp('good schedule');
    else
        disp('bad schedule');
    end
    
end

disp(final_time_sheet);

end

function result = test_schedule_script(time_sheet,people_time_sheet)

result = 0;

count = 0;

for person = 1:size(people_time_sheet,1)
    
    person_index = person+1;
    
    when_scheduled = find(time_sheet == person_index);
    person_schedule = find(people_time_sheet(person,:,:) == 0);
    
    if sum(ismember(when_scheduled,person_schedule)) > 1
        count = count + 1;
        result(count) = person;
        
    end
end

end

function [time_sheet final_time_sheet] = check_for_fixed_times(time_sheet,final_time_sheet)

source_filescsv = dir(fullfile(pwd, '*fixed_time.csv'));
count = 0;

for i = 1:length(source_filescsv)
    
    count = count + 1;
    
    person = source_filescsv(i).name(1:end-15);
    
    eval(sprintf('%s = csvread(''%s'',0,1,[0,1,95,5]);',person,source_filescsv(i).name));
    eval(sprintf('%s = check_dim(%s);',person,person));

    eval(sprintf('time_sheet = time_sheet + %s;',person));
    eval(sprintf('x = find(%s == 1);',person));
    
    for j = 1:length(x)
       eval(sprintf('final_time_sheet{x(j)} = ''%s'';',person)); 
    end
        
    
end


end



